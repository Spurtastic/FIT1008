from hash_table import LinearProbeHashTable
from typing import Tuple
import timeit


class Statistics:
    # TODO
    pass


class Dictionary:
    # TODO
    pass


if __name__ == '__main__':
    # TODO
    pass

